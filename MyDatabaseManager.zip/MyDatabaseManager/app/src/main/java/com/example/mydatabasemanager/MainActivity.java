package com.example.mydatabasemanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText inputName, inputSalary;
    private Spinner inputSpinnerDept;
    private DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database and views
        dbManager = new DatabaseManager(this);
        inputName = findViewById(R.id.inputName);
        inputSalary = findViewById(R.id.inputSalary);
        inputSpinnerDept = findViewById(R.id.inputSpinnerDept);

        // Set up the spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.departments,    // Reference to the array in strings.xml
                android.R.layout.simple_spinner_item // Layout for the spinner items
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // Dropdown layout
        inputSpinnerDept.setAdapter(adapter);

        // Button listeners
        findViewById(R.id.buttonAdd).setOnClickListener(v -> addEmployee());
        findViewById(R.id.buttonView).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EmployeeActivity.class);
            startActivity(intent);
        });
    }

    private void addEmployee() {
        String name = inputName.getText().toString().trim();
        String dept = inputSpinnerDept.getSelectedItem().toString();
        String salaryStr = inputSalary.getText().toString().trim();

        if (name.isEmpty() || salaryStr.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
            return;
        }

        double salary = Double.parseDouble(salaryStr);
        String joinDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());

        boolean isAdded = dbManager.addEmployee(name, dept, joinDate, salary);
        Toast.makeText(this, isAdded ? "Employee Added" : "Error Adding Employee", Toast.LENGTH_SHORT).show();
    }


}
