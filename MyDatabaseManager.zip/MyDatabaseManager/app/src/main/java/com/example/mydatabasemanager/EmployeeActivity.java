package com.example.mydatabasemanager;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import android.view.View;
import com.example.mydatabasemanager.Employee;

import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.ArrayList;
import java.util.ArrayList;

public class EmployeeActivity extends AppCompatActivity {

    List<Employee> employeeList;
    ListView listView;
    DatabaseManager mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);

        mDatabase = new DatabaseManager(this);
        employeeList = new ArrayList<>();
        listView = findViewById(R.id.myListView);

        loadEmployeesFromDatabase();
    }

    private void loadEmployeesFromDatabase() {
        // We are now using the DatabaseManager instance to get all employees
        Cursor cursor = mDatabase.getAllEmployees();

        if (cursor.moveToFirst()) {
            do {
                employeeList.add(new Employee(
                        cursor.getInt(0),  // ID
                        cursor.getString(1),  // Name
                        cursor.getString(2),  // Department
                        cursor.getString(3),  // Joining Date
                        cursor.getDouble(4)   // Salary
                ));

            } while (cursor.moveToNext());
        }

        // Prepare the employee adapter instance and bind the data to the adapter
        EmployeeAdapter adapter = new EmployeeAdapter(this, R.layout.list_layout_employee, employeeList, mDatabase);
        listView.setAdapter(adapter);
    }

    private void showUpdateDialog(final Employee employee) {
        // Create a dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_update_employee, null);
        builder.setView(dialogView);

        // Initialize dialog views
        EditText editTextName = dialogView.findViewById(R.id.editTextName);
        Spinner spinnerDepartment = dialogView.findViewById(R.id.spinnerDepartment);
        EditText editTextSalary = dialogView.findViewById(R.id.editTextSalary);
        Button buttonUpdate = dialogView.findViewById(R.id.buttonUpdateEmployee);

        // Set initial values
        editTextName.setText(employee.getName());
        editTextSalary.setText(String.valueOf(employee.getSalary()));

        // Populate spinner with departments
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.departments, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDepartment.setAdapter(adapter);
        spinnerDepartment.setSelection(adapter.getPosition(employee.getDepartment()));

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();

        // Handle the update button
        buttonUpdate.setOnClickListener(v -> {
            String updatedName = editTextName.getText().toString().trim();
            String updatedDepartment = spinnerDepartment.getSelectedItem().toString();
            double updatedSalary = Double.parseDouble(editTextSalary.getText().toString().trim());

            // Update in the database
            if (mDatabase.updateEmployee(employee.getId(), updatedName, updatedDepartment, updatedSalary)) {
                Toast.makeText(EmployeeActivity.this, "Employee updated", Toast.LENGTH_SHORT).show();
                loadEmployeesFromDatabase();
                dialog.dismiss();
            } else {
                Toast.makeText(EmployeeActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
